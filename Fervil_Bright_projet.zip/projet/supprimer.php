<?php
include "config.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $req = $pdo->prepare("DELETE FROM machine WHERE id = ?");
    $req->execute([$id]);

    header("Location: index.php");
}
?>