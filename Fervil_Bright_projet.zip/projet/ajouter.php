<?php include "config.php"; ?>
<link rel="stylesheet" href="style.css">


<header>
    <h1>Ajouter une machine</h1>
</header>


<div class="container">
<form method="POST">
Nom: <input name="nom"><br>
Type: <input name="type"><br>
IP: <input name="ip"><br>
Etat: <input name="etat"><br>
<button>Ajouter</button>
</form>

<a href="index.php">Retour</a>
<?php
if ($_POST) {
    $req = $pdo->prepare("INSERT INTO machine (nom, type, adresse_ip, etat)
                          VALUES (?, ?, ?, ?)");
    $req->execute([
        $_POST['nom'],
        $_POST['type'],
        $_POST['ip'],
        $_POST['etat']
    ]);

    echo "Machine ajoutée !";
}
?>