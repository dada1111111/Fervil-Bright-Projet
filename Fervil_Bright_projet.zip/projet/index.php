<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<?php include "config.php"; ?>
<link rel="stylesheet" href="style.css">


<header>
    <h1>ParkIT - Parc Informatique</h1>       <a href="logout.php">Se déconnecter</a>

</header>

<div class="container"></div>

<a href="ajouter.php">Ajouter une machine</a> |


<h2>Machines</h2>
<table border="1">
<tr>
<th>Nom</th><th>Type</th><th>IP</th><th>Etat</th><th>Action</th>
</tr>

<?php
$req = $pdo->query("SELECT * FROM machine");

while ($row = $req->fetch()) {
    echo "<tr>
        <td>{$row['nom']}</td>
        <td>{$row['type']}</td>
        <td>{$row['adresse_ip']}</td>
        <td>{$row['etat']}</td>
        <td>
            <a href='supprimer.php?id={$row['id']}' 
               onclick='return confirm(\"Supprimer cette machine ?\")'>
                Supprimer
            </a>
        </td>
    </tr>";
}
?>
</table>

