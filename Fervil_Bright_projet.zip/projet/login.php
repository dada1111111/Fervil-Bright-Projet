<?php
session_start();
include "config.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Connexion - ParkIT</h1>
    <p><a href="inscription.php">Créer un compte</a></p>
</header>

<div class="container">

<form method="POST">
    <label>Email :</label>
    <input type="email" name="email" required>

    <label>Mot de passe :</label>
    <input type="password" name="mdp" required>

    <button type="submit">Se connecter</button>
</form>

<?php
if ($_POST) {
    $email = $_POST['email'];
    $mdp = $_POST['mdp'];

  $req = $pdo->prepare("SELECT * FROM utilisateur WHERE email = ?");
$req->execute([$email]);

$user = $req->fetch();

if ($user && password_verify($mdp, $user['mdp'])) {
    $_SESSION['user'] = $user;
    header("Location: index.php");
} else {
    echo "<p style='color:red;'>Identifiants incorrects</p>";
}}
?>

</div>
</body>
</html>