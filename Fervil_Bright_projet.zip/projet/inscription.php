<?php
include "config.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inscription</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Inscription - ParkIT</h1>
</header>

<div class="container">
<p><a href="login.php">Connexion</a></p>
<form method="POST">
    <label>Nom :</label>
    <input type="text" name="nom" required>

    <label>Email :</label>
    <input type="email" name="email" required>

    <label>Mot de passe :</label>
    <input type="password" name="mdp" required>

    <label>Rôle :</label>
    <select name="role">
        <option value="employe">Employé</option>
        <option value="admin">Admin</option>
    </select>

    <button type="submit">S'inscrire</button>
</form>

<?php
if ($_POST) {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $mdp = password_hash($_POST['mdp'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // Vérifier si l'email existe déjà
    $check = $pdo->prepare("SELECT * FROM utilisateur WHERE email = ?");
    $check->execute([$email]);

    if ($check->fetch()) {
        echo "<p style='color:red;'>Email déjà utilisé</p>";
    } else {
        $req = $pdo->prepare("INSERT INTO utilisateur (nom, email, mdp, role)
                              VALUES (?, ?, ?, ?)");
        $req->execute([$nom, $email, $mdp, $role]);

        echo "<p style='color:green;'>Compte créé </p>";
        
    }
}
?>

</div>
</body>
</html>